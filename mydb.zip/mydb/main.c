#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>

#define DB_FILE "database.json"
#define DB_TMP "database.json.tmp"
#define MAX_TABLES 10
#define MAX_COLS 10
#define MAX_ROWS 100
#define NAME_LEN 32
#define TEXT_LEN 64

/* ячейка: число или текст */
typedef struct { int num; char text[TEXT_LEN]; } Cell;
/* столбец: имя и тип (0 = INTEGER, 1 = TEXT) */
typedef struct { char name[NAME_LEN]; int type; } Column;
/* таблица: имя, столбцы (структура), записи (данные) */
typedef struct {
    char name[NAME_LEN];
    int ncols;
    Column cols[MAX_COLS];
    int nrows;
    Cell rows[MAX_ROWS][MAX_COLS];
} Table;

Table tables[MAX_TABLES];
int ntables = 0;

/* ---------- вспомогательные функции ---------- */

char *trim(char *s) {
    while (*s == ' ' || *s == '\t') s++;
    int n = strlen(s);
    while (n > 0 && (s[n - 1] == ' ' || s[n - 1] == '\t')) s[--n] = '\0';
    return s;
}

int valid_name(const char *s) {
    if (*s == '\0') return 0;
    for (; *s; s++)
        if (!isalnum((unsigned char)*s) && *s != '_') return 0;
    return 1;
}

int find_table(const char *name) {
    for (int i = 0; i < ntables; i++)
        if (strcmp(tables[i].name, name) == 0) return i;
    return -1;
}

int find_col(Table *t, const char *name) {
    for (int i = 0; i < t->ncols; i++)
        if (strcmp(t->cols[i].name, name) == 0) return i;
    return -1;
}

/* превращает строку в значение нужного типа; 1 = успех, 0 = неверный тип */
int parse_value(int type, char *s, Cell *out) {
    if (type == 0) {                         /* INTEGER */
        int k = (s[0] == '-') ? 1 : 0;
        int len = strlen(s);
        if (s[k] == '\0' || len - k > 9) return 0;
        for (int i = k; s[i] != '\0'; i++)
            if (s[i] < '0' || s[i] > '9') return 0;
        out->num = atoi(s);
        return 1;
    }
    int L = strlen(s);                       /* TEXT */
    if (L < 2 || s[0] != '\'' || s[L - 1] != '\'') return 0;
    int n = L - 2;
    if (n > TEXT_LEN - 1) n = TEXT_LEN - 1;
    memcpy(out->text, s + 1, n);
    out->text[n] = '\0';
    return 1;
}

/* разбирает "column = value" (для WHERE и SET) */
int parse_assign(Table *t, char *s, int *col, Cell *val) {
    char *eq = strchr(s, '=');
    if (!eq) {
        printf("Error: syntax error, expected: column = value.\n");
        return 0;
    }
    *eq = '\0';
    char *cname = trim(s);
    char *v = trim(eq + 1);
    int c = find_col(t, cname);
    if (c == -1) {
        printf("Error: column '%s' does not exist in table '%s'.\n", cname, t->name);
        return 0;
    }
    if (!parse_value(t->cols[c].type, v, val)) {
        printf("Error: value '%s' does not match type %s of column '%s'.\n",
               v, t->cols[c].type == 0 ? "INTEGER" : "TEXT", cname);
        return 0;
    }
    *col = c;
    return 1;
}

/* подходит ли запись r под условие (wcol < 0 = условия нет) */
int match(Table *t, int r, int wcol, Cell *wv) {
    if (wcol < 0) return 1;
    if (t->cols[wcol].type == 0) return t->rows[r][wcol].num == wv->num;
    return strcmp(t->rows[r][wcol].text, wv->text) == 0;
}

/* ---------- сохранение в JSON ---------- */

void write_str(FILE *f, const char *s) {
    fputc('"', f);
    for (; *s; s++) {
        if (*s == '"' || *s == '\\') fputc('\\', f);
        fputc(*s, f);
    }
    fputc('"', f);
}

void save_db(void) {
    FILE *f = fopen(DB_TMP, "w");
    if (!f) {
        printf("Error: cannot save database.\n");
        return;
    }
    fprintf(f, "{\n  \"tables\": [");
    for (int i = 0; i < ntables; i++) {
        Table *t = &tables[i];
        fprintf(f, "%s\n    {\n      \"name\": ", i ? "," : "");
        write_str(f, t->name);
        fprintf(f, ",\n      \"columns\": [");
        for (int c = 0; c < t->ncols; c++) {
            fprintf(f, "%s{\"name\": ", c ? ", " : "");
            write_str(f, t->cols[c].name);
            fprintf(f, ", \"type\": \"%s\"}", t->cols[c].type == 0 ? "INTEGER" : "TEXT");
        }
        fprintf(f, "],\n      \"rows\": [");
        for (int r = 0; r < t->nrows; r++) {
            fprintf(f, "%s\n        [", r ? "," : "");
            for (int c = 0; c < t->ncols; c++) {
                if (c) fprintf(f, ", ");
                if (t->cols[c].type == 0) fprintf(f, "%d", t->rows[r][c].num);
                else write_str(f, t->rows[r][c].text);
            }
            fprintf(f, "]");
        }
        fprintf(f, "\n      ]\n    }");
    }
    fprintf(f, "\n  ]\n}\n");
    fclose(f);
    rename(DB_TMP, DB_FILE);
}

/* ---------- загрузка из JSON ---------- */

const char *jp;   /* текущая позиция в тексте JSON */
int jbad = 0;     /* 1 = файл повреждён */

void skip(void) {
    while (*jp == ' ' || *jp == '\n' || *jp == '\t' || *jp == '\r') jp++;
}

int peek(void) { skip(); return *jp; }

int expect(char c) {
    skip();
    if (*jp == c) { jp++; return 1; }
    jbad = 1;
    return 0;
}

void read_string(char *out, int max) {
    int n = 0;
    out[0] = '\0';
    if (!expect('"')) return;
    while (*jp && *jp != '"') {
        if (*jp == '\\' && jp[1]) jp++;
        if (n < max - 1) out[n++] = *jp;
        jp++;
    }
    if (*jp != '"') jbad = 1; else jp++;
    out[n] = '\0';
}

int read_int(void) {
    skip();
    char *end;
    long v = strtol(jp, &end, 10);
    if (end == jp) jbad = 1;
    jp = end;
    return (int)v;
}

int parse_db(void) {
    char tmp[64];
    expect('{'); read_string(tmp, 64); expect(':'); expect('[');
    while (!jbad && peek() != ']') {
        if (ntables >= MAX_TABLES) { jbad = 1; break; }
        Table *t = &tables[ntables];
        t->ncols = 0;
        t->nrows = 0;
        expect('{'); read_string(tmp, 64); expect(':');
        read_string(t->name, NAME_LEN); expect(',');
        read_string(tmp, 64); expect(':'); expect('[');
        while (!jbad && peek() != ']') {
            if (t->ncols >= MAX_COLS) { jbad = 1; break; }
            Column *c = &t->cols[t->ncols];
            expect('{'); read_string(tmp, 64); expect(':');
            read_string(c->name, NAME_LEN); expect(',');
            read_string(tmp, 64); expect(':'); read_string(tmp, 64);
            c->type = (strcmp(tmp, "TEXT") == 0);
            expect('}');
            t->ncols++;
            if (peek() == ',') jp++;
        }
        expect(']'); expect(',');
        read_string(tmp, 64); expect(':'); expect('[');
        while (!jbad && peek() != ']') {
            if (t->nrows >= MAX_ROWS) { jbad = 1; break; }
            expect('[');
            for (int i = 0; i < t->ncols && !jbad; i++) {
                if (i > 0) expect(',');
                if (t->cols[i].type == 0) t->rows[t->nrows][i].num = read_int();
                else read_string(t->rows[t->nrows][i].text, TEXT_LEN);
            }
            expect(']');
            t->nrows++;
            if (peek() == ',') jp++;
        }
        expect(']'); expect('}');
        ntables++;
        if (peek() == ',') jp++;
    }
    expect(']'); expect('}');
    return !jbad;
}

int load_db(void) {
    FILE *f = fopen(DB_FILE, "r");
    if (!f) {                       /* первый запуск: создаём пустую базу */
        save_db();
        return 1;
    }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);
    char *buf = malloc(size + 1);
    if (!buf) { fclose(f); return 0; }
    size_t got = fread(buf, 1, size, f);
    buf[got] = '\0';
    fclose(f);
    jp = buf;
    int ok = parse_db();
    free(buf);
    return ok;
}

/* ---------- SQL-команды ---------- */

int do_create(char *line) {
    char name[NAME_LEN];
    char *p = line + 12;                 /* после "CREATE TABLE" */
    char *open = strchr(p, '(');
    char *close = strrchr(p, ')');

    if (!open || !close || close < open) {
        printf("Error: syntax error. Use: CREATE TABLE name (col TYPE, ...);\n");
        return 0;
    }
    *open = '\0';
    *close = '\0';
    if (sscanf(p, "%31s", name) != 1) {
        printf("Error: table name is missing.\n");
        return 0;
    }
    if (!valid_name(name)) {
        printf("Error: invalid table name '%s'.\n", name);
        return 0;
    }
    if (find_table(name) != -1) {
        printf("Error: table '%s' already exists.\n", name);
        return 0;
    }
    if (ntables >= MAX_TABLES) {
        printf("Error: too many tables.\n");
        return 0;
    }

    Table *t = &tables[ntables];         /* заполняем, но ntables++ только в конце */
    strcpy(t->name, name);
    t->ncols = 0;
    t->nrows = 0;

    char *part = strtok(open + 1, ",");
    while (part != NULL) {
        char cname[NAME_LEN], ctype[16];
        if (sscanf(part, "%31s %15s", cname, ctype) != 2) {
            printf("Error: each column needs a name and a type.\n");
            return 0;
        }
        if (!valid_name(cname)) {
            printf("Error: invalid column name '%s'.\n", cname);
            return 0;
        }
        if (t->ncols >= MAX_COLS) {
            printf("Error: too many columns.\n");
            return 0;
        }
        strcpy(t->cols[t->ncols].name, cname);
        if (strcasecmp(ctype, "INTEGER") == 0) t->cols[t->ncols].type = 0;
        else if (strcasecmp(ctype, "TEXT") == 0) t->cols[t->ncols].type = 1;
        else {
            printf("Error: unknown type '%s'. Use INTEGER or TEXT.\n", ctype);
            return 0;
        }
        t->ncols++;
        part = strtok(NULL, ",");
    }
    if (t->ncols == 0) {
        printf("Error: table needs at least one column.\n");
        return 0;
    }
    ntables++;
    printf("Table '%s' created.\n", name);
    return 1;
}

int do_insert(char *line) {
    char name[NAME_LEN], kw[16];
    char *p = line + 11;                 /* после "INSERT INTO" */
    char *open = strchr(p, '(');
    char *close = strrchr(p, ')');

    if (!open || !close || close < open) {
        printf("Error: syntax error. Use: INSERT INTO name VALUES (v1, v2, ...);\n");
        return 0;
    }
    *open = '\0';
    *close = '\0';
    if (sscanf(p, "%31s %15s", name, kw) != 2 || strcasecmp(kw, "VALUES") != 0) {
        printf("Error: syntax error. Use: INSERT INTO name VALUES (v1, v2, ...);\n");
        return 0;
    }
    int ti = find_table(name);
    if (ti == -1) {
        printf("Error: table '%s' does not exist.\n", name);
        return 0;
    }
    Table *t = &tables[ti];
    if (t->nrows >= MAX_ROWS) {
        printf("Error: table is full.\n");
        return 0;
    }

    Cell row[MAX_COLS];                  /* сначала собираем запись отдельно */
    int n = 0;
    char *part = strtok(open + 1, ",");
    while (part != NULL) {
        if (n >= t->ncols) {
            printf("Error: too many values, table has %d columns.\n", t->ncols);
            return 0;
        }
        part = trim(part);
        if (!parse_value(t->cols[n].type, part, &row[n])) {
            printf("Error: value '%s' does not match type %s of column '%s'.\n",
                   part, t->cols[n].type == 0 ? "INTEGER" : "TEXT", t->cols[n].name);
            return 0;
        }
        n++;
        part = strtok(NULL, ",");
    }
    if (n != t->ncols) {
        printf("Error: expected %d values, got %d.\n", t->ncols, n);
        return 0;
    }
    for (int i = 0; i < n; i++) t->rows[t->nrows][i] = row[i];
    t->nrows++;
    printf("1 row inserted.\n");
    return 1;
}

void do_select(char *line) {
    char *cond = NULL;
    char *w = strcasestr(line, " WHERE ");
    if (w) { *w = '\0'; cond = w + 7; }

    char star[8], from[8], name[NAME_LEN], extra[2];
    if (sscanf(line + 6, "%7s %7s %31s %1s", star, from, name, extra) != 3
        || strcmp(star, "*") != 0 || strcasecmp(from, "FROM") != 0) {
        printf("Error: syntax error. Use: SELECT * FROM name [WHERE col = value];\n");
        return;
    }
    int ti = find_table(name);
    if (ti == -1) {
        printf("Error: table '%s' does not exist.\n", name);
        return;
    }
    Table *t = &tables[ti];
    int wcol = -1;
    Cell wval;
    if (cond && !parse_assign(t, cond, &wcol, &wval)) return;

    int width[MAX_COLS];                 /* ширина столбцов для красивого вывода */
    char buf[16];
    for (int c = 0; c < t->ncols; c++) {
        width[c] = strlen(t->cols[c].name);
        for (int r = 0; r < t->nrows; r++) {
            if (!match(t, r, wcol, &wval)) continue;
            int len;
            if (t->cols[c].type == 0) len = snprintf(buf, sizeof(buf), "%d", t->rows[r][c].num);
            else len = strlen(t->rows[r][c].text);
            if (len > width[c]) width[c] = len;
        }
    }
    for (int c = 0; c < t->ncols; c++)
        printf("%s%-*s", c ? " | " : "", width[c], t->cols[c].name);
    printf("\n");
    for (int c = 0; c < t->ncols; c++) {
        printf("%s", c ? "-+-" : "");
        for (int i = 0; i < width[c]; i++) printf("-");
    }
    printf("\n");
    int count = 0;
    for (int r = 0; r < t->nrows; r++) {
        if (!match(t, r, wcol, &wval)) continue;
        for (int c = 0; c < t->ncols; c++) {
            printf("%s", c ? " | " : "");
            if (t->cols[c].type == 0) printf("%-*d", width[c], t->rows[r][c].num);
            else printf("%-*s", width[c], t->rows[r][c].text);
        }
        printf("\n");
        count++;
    }
    printf("(%d rows)\n", count);
}

int do_update(char *line) {
    char *cond = NULL;
    char *w = strcasestr(line, " WHERE ");
    if (w) { *w = '\0'; cond = w + 7; }

    char name[NAME_LEN], kw[8];
    int n = 0;
    if (sscanf(line + 6, "%31s %7s%n", name, kw, &n) < 2 || strcasecmp(kw, "SET") != 0) {
        printf("Error: syntax error. Use: UPDATE name SET col = value [WHERE col = value];\n");
        return 0;
    }
    int ti = find_table(name);
    if (ti == -1) {
        printf("Error: table '%s' does not exist.\n", name);
        return 0;
    }
    Table *t = &tables[ti];
    int scol;
    Cell sval;
    if (!parse_assign(t, line + 6 + n, &scol, &sval)) return 0;
    int wcol = -1;
    Cell wval;
    if (cond && !parse_assign(t, cond, &wcol, &wval)) return 0;

    int count = 0;
    for (int r = 0; r < t->nrows; r++) {
        if (match(t, r, wcol, &wval)) {
            t->rows[r][scol] = sval;
            count++;
        }
    }
    printf("%d row(s) updated.\n", count);
    return 1;
}

int do_delete(char *line) {
    char *cond = NULL;
    char *w = strcasestr(line, " WHERE ");
    if (w) { *w = '\0'; cond = w + 7; }

    char from[8], name[NAME_LEN], extra[2];
    if (sscanf(line + 6, "%7s %31s %1s", from, name, extra) != 2
        || strcasecmp(from, "FROM") != 0) {
        printf("Error: syntax error. Use: DELETE FROM name [WHERE col = value];\n");
        return 0;
    }
    int ti = find_table(name);
    if (ti == -1) {
        printf("Error: table '%s' does not exist.\n", name);
        return 0;
    }
    Table *t = &tables[ti];
    int wcol = -1;
    Cell wval;
    if (cond && !parse_assign(t, cond, &wcol, &wval)) return 0;

    int j = 0, deleted = 0;              /* оставляем только нужные записи */
    for (int r = 0; r < t->nrows; r++) {
        if (match(t, r, wcol, &wval)) {
            deleted++;
        } else {
            for (int c = 0; c < t->ncols; c++) t->rows[j][c] = t->rows[r][c];
            j++;
        }
    }
    t->nrows = j;
    printf("%d row(s) deleted.\n", deleted);
    return 1;
}

/* ---------- главная программа ---------- */

int main(void) {
    char line[1024];

    if (!load_db()) {
        printf("Error: cannot read %s (file is damaged). Fix or delete it.\n", DB_FILE);
        return 1;
    }
    printf("MiniSQLite\n");
    printf("Type .help for help.\n");

    while (1) {
        printf("minidb> ");
        if (fgets(line, sizeof(line), stdin) == NULL) break;
        line[strcspn(line, "\n")] = '\0';

        int len = strlen(line);
        while (len > 0 && (line[len - 1] == ' ' || line[len - 1] == '\t'))
            line[--len] = '\0';
        if (len == 0) continue;

        if (line[0] == '.') {
            if (strcmp(line, ".exit") == 0) break;
            else if (strcmp(line, ".help") == 0) {
                printf("Commands:\n");
                printf("  .help     show this help\n");
                printf("  .tables   show tables\n");
                printf("  .exit     quit\n");
                printf("Examples:\n");
                printf("  CREATE TABLE students (id INTEGER, name TEXT, age INTEGER);\n");
                printf("  INSERT INTO students VALUES (1, 'Ani', 20);\n");
                printf("  SELECT * FROM students;\n");
                printf("  SELECT * FROM students WHERE id = 1;\n");
                printf("  UPDATE students SET age = 21 WHERE id = 1;\n");
                printf("  DELETE FROM students WHERE id = 2;\n");
            } else if (strcmp(line, ".tables") == 0) {
                if (ntables == 0) printf("(no tables)\n");
                for (int i = 0; i < ntables; i++) printf("%s\n", tables[i].name);
            } else printf("Error: unknown command\n");
            continue;
        }

        if (line[len - 1] != ';') {
            printf("Error: command must end with ;\n");
            continue;
        }
        line[len - 1] = '\0';

        int changed = 0;
        if (strncasecmp(line, "CREATE TABLE", 12) == 0) changed = do_create(line);
        else if (strncasecmp(line, "INSERT INTO", 11) == 0) changed = do_insert(line);
        else if (strncasecmp(line, "SELECT", 6) == 0) do_select(line);
        else if (strncasecmp(line, "UPDATE", 6) == 0) changed = do_update(line);
        else if (strncasecmp(line, "DELETE", 6) == 0) changed = do_delete(line);
        else printf("Error: unknown command\n");

        if (changed) save_db();          /* сохраняем только после успешного изменения */
    }
    return 0;
}